#include <vector>

using std::vector;

int main()
{
    vector<int> ivec{0};
    ivec[0] = 42;
    return 0;
}
