### Exercise information

<!-- 
Exercise 1.1
> Review the documentation for your compiler and determine what file naming convention it uses. Compile and run the main program from page 2.
-->
Exercise xx.xx

### Question or Bug

<!--
cannot compile.
-->

### Your enviroment information

- **System**:  :grey_question:
- **Compiler version/IDE**:  :grey_question:
