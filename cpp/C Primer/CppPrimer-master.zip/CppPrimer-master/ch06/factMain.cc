#include "Chapter6.h"
#include <iostream>

int main()
{
    std::cout << "5! is " << fact(5) << std::endl;
    std::cout << func() << std::endl;
    std::cout << abs(-9.78) << std::endl;
}
