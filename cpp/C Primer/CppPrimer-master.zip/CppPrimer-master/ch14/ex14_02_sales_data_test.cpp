#include "ex14_02_sales_data.h"

int main()
{
    Sales_data cp5;
    std::cin >> cp5;
    std::cout << cp5 << std::endl;
}

// compile
// cc -g ex14_02_sales_data_test.cpp ex14_02_sales_data.cpp -std=c++11 -pedantic
// -Wall