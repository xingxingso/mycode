#include "ex14_22_sales_data.h"

int main()
{
    std::string strCp5("C++ Primer 5th");
    Sales_data cp5 = strCp5;
    std::cout << cp5 << std::endl;
}
